# Category Theory Bundle
## Overview
This bundle contains the foundational elements of category theory, structured for modular learning and reference.

## Roadmap
1. **Core Definitions**: Categories, Functors, Natural Transformations.
2. **Limits & Colimits**: Products, Coproducts, Equalizers, Coequalizers, Pullbacks, Pushouts.
3. **Adjunctions & Monads**: Adjoint functors, Monad/Comonad structures, Kan Extensions.
4. **Resources**: Curated list of textbooks, online wikis, and interactive tools.

## Navigation
- Core: `core/category.md`, `core/functor.md`, `core/natural_transformation.md`
- Limits/Colimits: `adv/limits_colimits.md`
- Adjunctions: `adv/adjunctions.md`
- Resources: `resources.md`