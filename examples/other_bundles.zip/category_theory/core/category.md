# Category
A category $\mathcal{C}$ consists of:
- A collection of **objects** $Obj(\mathcal{C})$.
- For every pair of objects $(A, B)$, a set of **morphisms** $Hom(A, B)$.
- A **composition law**: for $f \in Hom(A, B)$ and $g \in Hom(B, C)$, there is $g \circ f \in Hom(A, C)$.
- **Identity morphisms**: For every object $A$, there is an identity $id_A \in Hom(A, A)$.

## Axioms
1.  **Associativity**: $h \circ (g \circ f) = (h \circ g) \circ f$.
2.  **Identity**: $f \circ id_A = f$ and $id_B \circ f = f$.

## Examples
- **Set**: Objects are sets, morphisms are functions.
- **Grp**: Objects are groups, morphisms are group homomorphisms.
- **Top**: Objects are topological spaces, morphisms are continuous maps.
- **Vect**: Objects are vector spaces over a field $k$, morphisms are linear transformations.
