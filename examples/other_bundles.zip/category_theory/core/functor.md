# Functors
A **Functor** $F$ from a category $\mathcal{C}$ to a category $\mathcal{D}$ is a mapping that preserves the categorical structure.

## Definition
A functor $F: \mathcal{C} \to \mathcal{D}$ consists of:
1.  **Object Mapping**: For each object $X \in Ob(\mathcal{C})$, an object $F(X) \in Ob(\mathcal{D})$.
2.  **Morphism Mapping**: For every morphism $f: X \to Y$ in $\mathcal{C}$, a morphism $F(f): F(X) \to F(Y)$ in $\mathcal{D}$.

## Axioms
1.  **Identity Preservation**: $F(id_X) = id_{F(X)}$ for every $X \in Ob(\mathcal{C})$.
2.  **Composition Preservation**: $F(g \circ f) = F(g) \circ F(f)$ for all $f, g$ in $\mathcal{C}$.

## Examples
- **Forgetful Functor**: From $\mathbf{Grp}$ to $\mathbf{Set}$, mapping a group to its underlying set.
- **Free Functor**: Taking a set and forming the free group/monoid over it.
- **Hom-functor**: $Hom(A, -)$ (covariant) or $Hom(-, B)$ (contravariant).