# Natural Transformations
A **Natural Transformation** $\alpha$ is a way of "morphisming" between two functors $F, G: \mathcal{C} \to \mathcal{D}$.

## Definition
Given two functors $F, G: \mathcal{C} \to \mathcal{D}$, a natural transformation $\alpha: F \Rightarrow G$ consists of:
- For each object $X \in Ob(\mathcal{C})$, a morphism $\alpha_X: F(X) \to G(X)$ in $\mathcal{D}$.

## Naturality Condition
For any morphism $f: X \to Y$ in $\mathcal{C}$, the following diagram must commute:
$$
\begin{array}{ccc}
F(X) & \xrightarrow{\alpha_X} & G(X) \\
\downarrow F(f) & & \downarrow G(f) \\
F(Y) & \xrightarrow{\alpha_Y} & G(Y)
\end{array}
$$
Formally: $G(f) \circ \alpha_X = \alpha_Y \circ F(f)$.

## Key Concept
Natural transformations allow us to compare different ways of mapping one category to another. If $\alpha$ is an isomorphism at every component, it is called a **natural isomorphism**.