# Adjunctions and Monads

## Adjunctions
An **adjunction** between two categories $\mathcal{C}$ and $\mathcal{D}$ consists of a pair of functors $F: \mathcal{C} \to \mathcal{D}$ (left adjoint) and $G: \mathcal{D} \to \mathcal{C}$ (right adjoint), denoted $F \dashv G$.

### Definition
There is a natural isomorphism between Hom-sets:
$$Hom_{\mathcal{D}}(F(X), Y) \cong Hom_{\mathcal{C}}(X, G(Y))$$

## Monads
A **Monad** $(T, \mu, \eta)$ on a category $\mathcal{C}$ is a triple where $T: \mathcal{C} \to \mathcal{C}$ is an endofunctor, $\eta$ is the unit natural transformation ($Id \Rightarrow T$), and $\mu$ is the multiplication ($\mu: T^2 \Rightarrow T$).

### Relationship to Adjunctions
Every adjunction $F \dashv G$ defines a monad on $\mathcal{C}$ given by $T = G \circ F$. This provides the framework for "computation" in many programming languages (e.g., Haskell).

## Kan Extensions
Kan extensions are a generalization of both limits and adjunctions, providing a way to extend a functor along another morphism.