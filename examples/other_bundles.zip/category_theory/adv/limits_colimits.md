# Limits and Colimits

## Limits
A **limit** is an object that "generalizes" concepts like products and equalizers. Given a diagram $F: \mathcal{I} \to \mathcal{C}$ (where $\mathcal{I}$ is index category), the limit of $F$ is an object $L$ together with morphisms from $L$ to each $F(i)$ such that they satisfy specific uniqueness properties.

### Common Limits
- **Products**: Limit over a discrete category (e.g., $A \times B$).
- **Equalizers**: Limit of a diagram with two parallel arrows.
- **Pullbacks**: Limit of a diagram from $X \to Z \leftarrow Y$.
- **Terminal Object**: Limit of a diagram over the empty index category.

## Colimits
A **colimit** is the dual concept to limits. It generalizes coproducts and coequalizers.

### Common Colimits
- **Coproducts**: (e.g., $A \oplus B$).
- **Coequalizers**.
- **Pushouts**.
- **Initial Object**: Colimit over an empty index category.

## Universal Properties
Limits and colimits are defined by their universal properties: they are the "best" way to complete a diagram.