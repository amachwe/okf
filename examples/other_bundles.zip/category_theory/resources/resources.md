# External Resources

## Online Repositories
- **nLab**: The primary wiki for category theory (nlab.cc).
- **ProofWiki**: For formal proofs of categorical properties.

## Textbooks
1.  **"Categories for the Working Mathematician"** by Saunders Mac Lane and Stephen E. Morton. (The "Bible" of Category Theory).
2.  **"Higher-Dimensional Categories"** - Various modern texts on $\infty$-categories.

## Online Lectures/Courses
- **The Bright Side of Mathematics**: Excellent YouTube series on category theory basics.
- **Coursera / edX**: Search for functional programming courses (often include heavy Category Theory components).

## Software Tools
- **Catlab.jl**: A library in Julia for doing mathematics with categories.
- **Agda/Coq**: Used for formalizing categorical proofs.