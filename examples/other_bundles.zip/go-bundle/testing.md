---
title: Testing Go Applications
description: Comprehensive testing strategies including unit tests, fuzzing, and benchmarking.
links:
  - name: Index
    url: index.md
  - name: Creating
    url: creation.md
  - name: Debugging
    url: debugging.md
  - name: Performance Improvement
    url: performance.md
---

# Testing Go Applications

## Unit Testing
Use the built-in `testing` package.
- **Standard Test:** `func TestAdd(t *testing.T) { ... }`
- **Subtests:** Use `t.Run("description", func(t *testing.T) { ... })` to organize complex test cases.

## Table-Driven Tests
The idiomatic way to test multiple inputs for the same logic:
```go
func TestAdd(t *testing.T) {
    tests := []struct {
        name string
        a, b, want int
    }{
        {"positive", 1, 2, 3},
        {"negative", -1, -1, -2},
        {"zero", 0, 0, 0},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            if got := Add(tt.a, tt.b); got != tt.want {
                t.Errorf("got %v, want %v", got, tt.want)
            }
        })
    }
}
```

## Fuzz Testing (Go 1.18+)
Automatically generate random inputs to find edge cases.
```go
func FuzzAdd(f *testing.F) {
    f.Add(1, 2) // Seed corpus
    f.Fuzz(func(t *testing.T, a, b int) {
        if result := Add(a, b); result != a+b {
            t.Errorf("Add(%d, %d) = %d; want %d", a, b, result, a+b)
        }
    })
}
```

## Benchmarking
Measure performance and memory allocation.
- **Command:** `go test -bench=. -benchmem`
- **Analysis:** Look for `B/op` (bytes per operation) and `allocs/op` to identify allocation hotspots.

## Useful Libraries
- **testify:** Provides `assert` and `require` packages to simplify check logic.
- **sqlmock:** Mock SQL database connections for integration tests.
- **testcontainers-go:** Run real database instances in Docker during tests.
