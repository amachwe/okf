---
title: Debugging Go Applications
description: Advanced techniques and tools for identifying, tracing, and fixing bugs in Go code.
links:
  - name: Index
    url: index.md
  - name: Creating
    url: creation.md
  - name: Testing
    url: testing.md
  - name: Performance Improvement
    url: performance.md
---

# Debugging Go Applications

## Delve (dlv)
Delve is the standard debugger for Go. Unlike `gdb`, it understands Go's runtime.
- **Run:** `dlv debug main.go`
- **Attach:** `dlv exec --listen=:2345` (use for production/running processes)
- **Inspection:** Use `locals`, `stack`, and `print` to examine state at a breakpoint.

## Logging & Observability
Go's standard `log` is simple but lacks structure.
- **slog (Standard Library):** Use `log/slog` for structured logging.
  ```go
  import "log/slog"
  slog.Info("user login", "user_id", 123, "status", "success")
  ```
- **Contextual Logging:** Always pass `context.Context` to your functions to carry trace IDs and request metadata.

## Error Handling & Wrapping
Wrap errors to provide a stack trace or context:
```go
if err := db.Exec(...); err != nil {
    return fmt.Errorf("failed to update user %d: %w", userID, err)
}
```

## Concurrency Debugging
- **Race Detector:** Always run tests with `-race`.
  ```bash
  go test -race ./...
  ```
- **Goroutine Leak Detection:** Use `runtime.NumGoroutine()` or `uber-go/goleak` to ensure goroutines are closed properly.

## Common Pitfalls
- **Nil Pointer Dereferences:** Check pointers before dereferencing.
- **Unclosed Channels/Bodies:** Always use `defer resp.Body.Close()`.
- **Variable Shadowing:** Be careful with `:=` in nested blocks.
