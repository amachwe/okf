---
title: Go Development Overview
description: A comprehensive guide to building, debugging, testing, and optimizing Go applications.
links:
  - name: Creating
    url: creation.md
  - name: Debugging
    url: debugging.md
  - name: Testing
    url: testing.md
  - name: Performance Improvement
    url: performance.md
---

# Go Development Overview

Welcome to the Go development knowledge base. This bundle provides structured information to help you master the Go ecosystem.

## Core Areas
1. **Creating**: Initializing projects, advanced project structure, and managing complex dependency graphs.
2. **Debugging**: Mastery of Delve (dlv), structured logging with `slog`, and identifying concurrency issues.
3. **Testing**: Beyond basics�including Table-Driven Tests, Benchmark analysis, and Fuzzing.
4. **Performance**: In-depth profiling with `pprof`, escape analysis, and memory optimization.

Explore the links above to dive into specific areas.
