---
title: Creating Go Projects
description: Guidance on project structure, initialization, and advanced configuration management.
links:
  - name: Index
    url: index.md
  - name: Debugging
    url: debugging.md
  - name: Testing
    url: testing.md
  - name: Performance Improvement
    url: performance.md
---

# Creating Go Projects

## Project Initialization
Initialize a module with a clear path:
```bash
go mod init github.com/username/projectname
```

## Project Structure (Standard Layout)
- `/cmd`: Applications entry points (e.g., `cmd/server/main.go`).
- `/internal`: Code private to the project; not importable by others.
- `/pkg`: Library code intended for public use.
- `/api`: OpenAPI/Swagger specs or Protobuf definitions.
- `/configs`: Configuration files (YAML, TOML, etc.).

## Dependency Management
- `go mod tidy`: Cleans up unused modules and adds missing ones.
- `go mod verify`: Verifies that dependencies match the expected checksums.
- `go mod graph`: Displays the dependency graph.

## Configuration Management
Use environment variables for configuration.
- `os.Getenv("PORT")`: Standard way to fetch environment variables.
- **Tools**: Use `viper` or `caarlos0/env` for advanced configuration handling (loading from files, envs, and defaults).

## Build Tags
Control compilation based on environment or platform:
```go
// +build !no_main
package main
```
Use `//go:build` for Go 1.17+.
