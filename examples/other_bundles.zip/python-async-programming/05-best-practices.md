# Module 5: Best Practices & Pitfalls

## The Golden Rule: Never Block the Event Loop
The most critical rule in `asyncio` is: **Do not perform blocking operations inside an `async def` function.**
If you use a blocking call (like `time.sleep()`, `requests.get()`, or a long-running mathematical loop), the entire event loop stops. This means every other concurrent task stops waiting for I/O�they literally cannot move because the thread they run on is stuck.

### How to detect blocking:
- Using `time.sleep()` instead of `await asyncio.sleep()`.
- Using `requests` or `ur_lib` instead of `aiohttp` or `httpx`.
- Performing heavy CPU calculations (should be offloaded to `ProcessPoolExecutor`).

## Handling Blocking Code
If you **must** use a library that doesn't support async (like a specific database driver), use `asyncio.to_thread()`:
```python
import asyncio
import time

def blocking_io():
    time.sleep(5) # This would normally freeze the whole loop
    return "Done"

async def main():
    # This runs the function in a separate thread, so the loop stays free
    result = await asyncio.to_thread(blocking_io)
    print(result)
```

## Modern Task Management (Python 3.11+)
Use `TaskGroup` instead of `asyncio.gather` for better error handling and structured concurrency. If one task in a `TaskGroup` fails, the others are cancelled automatically.

```python
async def main():
    async with asyncio.TaskGroup() as tg:
        tg.create_task(fetch_data(1))
        tg.create_task(fetch_data(2))
    # Execution only reaches here after all tasks in the group finish.
```

## Critical Checklist
1. **Use `asyncio.run(main())`**: Only call this once at the very entry point of your program.
2. **Context Managers**: Use `async with` for sessions and files to ensure they are closed properly.
3. **Timeouts**: Always wrap network calls in `asyncio.wait_for(coro, timeout=...)` to prevent hanging.
4. **Logging**: Use the `logging` module; standard `print` statements are generally okay but don't provide the same context in concurrent environments.
