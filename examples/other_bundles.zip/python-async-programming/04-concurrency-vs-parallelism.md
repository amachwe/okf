# Module 4: Concurrency vs. Parallelism

## Defining the Terms
- **Concurrency**: Managing multiple tasks at once by interleaving their execution. (Example: `asyncio`).
- **Parallelism**: Executing multiple tasks at the exact same moment. (Example: `multiprocessing`).

## The Role of the Python GIL (Global Interpreter Lock)
The GIL is a mutex that allows only one thread to execute Python bytecode at a time.
- **Threading**: Because of the GIL, even if you have 10 threads, only one can execute Python code at any given microsecond. However, when a thread waits for I/O (like a network response), it releases the lock, allowing another thread to run.
- **Multiprocessing**: Each process has its own Python interpreter and its own GIL. This allows true parallel execution on multi-core CPUs.

## Workload Categorization
### 1. I/O-Bound (Wait-heavy)
- Examples: Web scraping, API calls, database queries, reading/writing files.
- **Recommended Tool**: `asyncio` (Concurrency).
- **Why**: It's extremely efficient for managing thousands of connections without the memory overhead of many threads or processes.

### 2. CPU-Bound (Calculation-heavy)
- Examples: Image processing, heavy mathematical calculations, machine learning model training, encryption.
- **Recommended Tool**: `multiprocessing` (Parallelism).
- **Why**: Since the GIL prevents threads from utilizing multiple cores, you need separate processes to achieve true parallelism.

## Decision Matrix
| Use Case | Best Choice | Why? |
| :--- | :--- | :--- |
| Web Scraper | `asyncio` | Handles many network waits concurrently. |
| Chat Server | `asyncio` | Handles thousands of concurrent connections. |
| Video Encoding | `multiprocessing` | Requires raw CPU power. |
| Heavy Math | `multiprocessing` | Needs to bypass the GIL. |
| Legacy I/O (blocking) | `threading` | Good when a library doesn't have an async version. |
