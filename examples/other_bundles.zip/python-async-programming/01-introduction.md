# Module 1: Introduction to Asynchronous Programming

## The Fundamentals
### Synchronous vs. Asynchronous Execution
- **Synchronous (Blocking):** Tasks are performed one after another. If a task involves waiting (e.g., a network request), the entire execution thread is "blocked" and sits idle until the data returns.
- **Asynchronous (Non-blocking):** While one task waits for an external operation (I/O), the execution flow is released so other tasks can progress. This doesn't mean tasks run "at the same time" in terms of CPU execution, but they progress concurrently in time.

### The Mechanics
- **The Event Loop:** Think of this as a central scheduler. It maintains a list of active tasks. When a task reaches a point where it must wait (e.g., `await`), it signals the loop, and the loop moves on to the next task. When the I/O operation finishes, the loop resumes the original task from where it left off.
- **Coroutines:** Functions defined with `async def`. Unlike standard functions, they don't run immediately when called. They return a "coroutine object" that must be scheduled by the loop.
- **Awaitables:** Objects that can be used in an `await` expression. These include Coroutines, Tasks, and Futures.

### History & Evolution
- **Generator-based:** Early async in Python used `@_yield_from` and `yield`.
- **Async/Await (Python 3.5+):** The current standard, providing a much cleaner syntax and making code look more like synchronous code while retaining non-blocking benefits.

## Example: The "Awaiting" Lifecycle
```python
import asyncio

async def fetch_data_simulated():
    print("Fetching data...")
    # The loop "pauses" this function and moves to other tasks
    await asyncio.sleep(2) 
    print("Data received.")
    return {"data": 123}

async def main():
    # Logic for starting the engine
    result = await fetch_data_simulated()
    print(result)

if __name__ == "__main__":
    asyncio.run(main())
```
