# Module 6: Advanced Topics

## Async Iterators and Generators
Async iterators allow you to iterate over data that is produced asynchronously (e.g., streaming data from a network).
```python
async for item in async_generator():
    print(item)
```

## Async Context Managers
Used to manage resources (like database connections or files) in an async way.
```python
async with aiohcm.AsyncContextManager() as resource:
    # work with resource
```

## Synchronization Primitives
Just like threading, asyncio provides primitives to coordinate access to shared resources when needed:
- **Lock**: `asyncio.Lock()`
- **Semaphore**: `asyncio.Semaphore()`
- **Queue**: `asyncio.Queue()` (Excellent for producer/consumer patterns).

## Integration with Threads/Processes
Use `loop.run_in_executor()` to run blocking code in a separate thread or process while keeping the main loop running.
