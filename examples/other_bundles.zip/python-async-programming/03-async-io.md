# Module 3: Asynchronous I/O

## The Need for Async I/O
Standard Python libraries like `requests` are **synchronous**. When you perform a request, the thread blocks. In a high-concurrency environment (like a web server or scraper), this is inefficient. `asyncio` libraries allow the application to handle thousands of concurrent connections on a single thread.

## Key Libraries
1. **`aiohttp`**: The gold standard for asynchronous HTTP clients and servers.
2. **`httpx`**: A modern client that supports both sync and async; very similar API to `requests`.
3. **`aiofiles`**: Used for asynchronous file system operations (since standard file I/O is blocking).

## Important Concept: Session Management
In `aiohttp`, you should **not** create a new session for every request. Creating a session involves establishing connection pools. You should use a single `ClientSession` for your application's lifetime or at least for a batch of related requests.

## Implementation Example with `aiohttp`
```python
import aiohttp
import asyncio

async def fetch_page(session, url):
    try:
        async with session.get(url, timeout=10) as response:
            # Process the response immediately
            status = response.status
            content = await response.text()
            print(f"Fetched {url} with status {status}")
            return len(content)
    except Exception as e:
        print(f"Error fetching {url}: {e}")

async def main():
    # A single session is shared among all requests
    async with aiohttp.ClientSession() as session:
        urls = [
            "https://www.google.com",
            "https://www.python.org",
            "https://github.com"
        ]
        # Create a list of tasks
        tasks = [fetch_page(session, url) for url in urls]
        
        # Execute concurrently
        results = await asyncio.gather(*tasks)
        print(f"Fetched lengths: {results}")

if __name__ == "__main__":
    asyncio.run(main())
```
