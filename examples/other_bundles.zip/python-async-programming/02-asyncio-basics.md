# Module 2: The `asyncio` Library

## Core Task Management
- **Coroutines vs. Tasks**: 
    - A **Coroutine** is the code defined by `async def`. 
    - A **Task** is the wrapper that schedules the coroutine to run on the event loop. Using `asyncio.create_task(coro())` schedules it immediately.
- **`asyncio.gather(*aws)`**: Use this when you want to run multiple things at once and need all their results back as a list. It's the standard way to start a batch of concurrent tasks.
- **`asyncio.wait(aws)`**: Used when you need more control. It returns a set of `(task, done)` pairs. It allows you to check which tasks finished first or wait for a specific number to complete.
- **`asyncio.as_completed(aws)`**: Returns an iterator that yields results as they finish, regardless of the order they were started. Useful for processing results in real-time.

## Execution Flow Example
```python
import asyncio
import time

async def task_worker(name, delay):
    print(f"Worker {name} starting (will take {delay}s)")
    await asyncio.sleep(delay)
    print(f"Worker {name} finished.")
    return f"Result {name}"

async def main():
    # Method 1: asyncio.gather (Best for "do all these things and give me the list")
    start = time.perf_counter()
    results = await asyncio.gather(
        task_worker("A", 3),
        task_worker("B", 1),
        task_worker("C", 2)
    )
    print(f"Gather results: {results}")
    print(f"Total time with gather: {time.perf_counter() - start:.2f}s")

    print("-" * 30)

    # Method 2: asyncio.as_completed (Best for "process items as they finish")
    start = time.perf_counter()
    tasks = [task_worker(f"{i}", i) for i in range(1, 4)]
    for task in asyncio.as_completed([task_worker(f"D{i}", i) for i in range(1, 4)]):
        res = await task
        print(f"Received: {res}")
    
    print(f"Total time with as_completed: {time.perf_counter() - start:.2f}s")

if __name__ == "__main__":
    asyncio.run(main())
```
