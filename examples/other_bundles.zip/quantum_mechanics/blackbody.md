Derivation: Blackbody Radiation from Quantized Modes

  Setup: the problem this solves

  Classically, treating the EM field in a cavity as continuous waves in thermal equilibrium leads to the Rayleigh–Jeans law, where each mode gets average energy $k_BT$ (equipartition).
  Since the number of modes grows as $\nu^2$, the radiated energy diverges at high frequency — the ultraviolet catastrophe. Planck fixed this by quantizing the energy of each mode.
  Here's the full derivation.

  Step 1 — Count the modes (density of states)

  Consider a cubic cavity, side $L$, volume $V = L^3$, perfectly reflecting walls. Standing-wave boundary conditions restrict the allowed wavevectors to
  $$k_x = \frac{n_x\pi}{L},\quad k_y=\frac{n_y\pi}{L},\quad k_z=\frac{n_z\pi}{L}, \qquad n_x,n_y,n_z = 1,2,3,\dots$$

  Counting points in $k$-space (positive octant only, then ×2 for the two independent photon polarizations), the number of modes with wavevector magnitude in $[k, k+dk]$ is
  $$dN = 2\cdot\frac{1}{8}\cdot 4\pi k^2,dk \Big/ \left(\frac{\pi}{L}\right)^3 = \frac{V}{\pi^2}k^2,dk$$

  With $\omega = ck$:
  $$dN = \frac{V,\omega^2}{\pi^2 c^3},d\omega$$

  This is a purely classical wave-counting result — the quantum step comes next.

  Step 2 — Quantize each mode

  Each cavity mode is mathematically a harmonic oscillator. Solving its Schrödinger equation gives discrete energy levels (same quantization logic as
  quantum_mechanics/02-schrodinger-equation.md):
  $$E_n = n\hbar\omega, \qquad n = 0, 1, 2, \dots$$

  ($n$ here counts photons in the mode.) This discreteness is Planck's key departure from classical physics — energy can only be exchanged with the mode in packets of $\hbar\omega$.

  Step 3 — Average energy per mode (statistical mechanics)

  Treat each mode as a system in thermal equilibrium at temperature $T$, governed by the Boltzmann distribution (the statistical foundation underlying the entropy/second-law bundle).
  The partition function is a geometric series:
  $$Z = \sum_{n=0}^{\infty} e^{-n\hbar\omega/k_BT} = \frac{1}{1 - e^{-\hbar\omega/k_BT}}$$

  The mean energy follows from $\langle E\rangle = -\dfrac{\partial \ln Z}{\partial \beta}$, $\beta = 1/k_BT$:
  $$\boxed{\langle E(\omega)\rangle = \frac{\hbar\omega}{e^{\hbar\omega/k_BT}-1}}$$

  Compare this to the classical equipartition result $\langle E\rangle = k_BT$ (which you'd get by replacing the sum over discrete $n$ with an integral). Quantization suppresses the
  average energy of high-frequency modes exponentially — this is what will cure the UV catastrophe.

  Step 4 — Spectral energy density (Planck's Law)

  Multiply the mode density (Step 1) by the average energy per mode (Step 3), divide by volume:
  $$u(\omega,T),d\omega = \frac{\langle E\rangle,dN}{V} = \frac{\hbar\omega^3}{\pi^2c^3}\cdot\frac{1}{e^{\hbar\omega/k_BT}-1},d\omega$$

  Converting to ordinary frequency $\nu=\omega/2\pi$ gives the familiar form:
  $$\boxed{u(\nu,T),d\nu = \frac{8\pi h\nu^3}{c^3}\cdot\frac{1}{e^{h\nu/k_BT}-1},d\nu}$$

  This is Planck's blackbody radiation law.

  Step 5 — Check the limits

  - Low frequency ($h\nu \ll k_BT$): expand $e^{h\nu/k_BT}-1 \approx h\nu/k_BT$, giving
  $$u(\nu,T) \to \frac{8\pi\nu^2}{c^3}k_BT \quad \text{(Rayleigh–Jeans law — classical limit recovered)}$$
  - High frequency ($h\nu \gg k_BT$): the $-1$ becomes negligible, giving
  $$u(\nu,T) \to \frac{8\pi h\nu^3}{c^3}e^{-h\nu/k_BT} \quad \text{(Wien's law — exponential cutoff, no UV catastrophe)}$$

  Step 6 — Stefan–Boltzmann law (integrate over all frequencies)

  $$u(T) = \int_0^\infty u(\nu,T),d\nu = \frac{8\pi h}{c^3}\left(\frac{k_BT}{h}\right)^4\int_0^\infty \frac{x^3}{e^x-1},dx,\qquad x=\frac{h\nu}{k_BT}$$

  Using the standard result $\displaystyle\int_0^\infty \frac{x^3}{e^x-1}dx = \frac{\pi^4}{15}$:
  $$u(T) = \frac{8\pi^5k_B^4}{15h^3c^3},T^4 = a,T^4$$

  Relating energy density to emitted power per unit area ($P = \tfrac{c}{4}u$) gives the Stefan–Boltzmann law:
  $$P = \sigma T^4, \qquad \sigma = \frac{2\pi^5 k_B^4}{15h^3c^2} \approx 5.67\times10^{-8}\ \text{W m}^{-2}\text{K}^{-4}$$

  Summary of the quantum → thermodynamic chain

  ┌─────────────────────────────┬─────────────────────────────────┬────────────────────────┐
  │            Step             │             Concept             │         Bundle         │
  ├─────────────────────────────┼─────────────────────────────────┼────────────────────────┤
  │ Mode counting               │ Wave boundary conditions        │ (classical EM)         │
  ├─────────────────────────────┼─────────────────────────────────┼────────────────────────┤
  │ Discrete $E_n=n\hbar\omega$ │ Quantized energy levels         │ quantum_mechanics      │
  ├─────────────────────────────┼─────────────────────────────────┼────────────────────────┤
  │ Boltzmann-weighted average  │ Statistical mechanics / entropy │ laws_of_thermodynamics │
  ├─────────────────────────────┼─────────────────────────────────┼────────────────────────┤
  │ $u(\nu,T)$, $\sigma T^4$    │ Macroscopic thermodynamic law   │ Result                 │
  └─────────────────────────────┴─────────────────────────────────┴────────────────────────┘

  This is the direct link back to your earlier question: quantization (discrete $\hbar\omega$ steps) is exactly what converts a divergent classical thermodynamic prediction into the
  finite, experimentally correct Planck law.